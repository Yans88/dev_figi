<?php
$mod_url = './?mod=portal&portal=student_usage';
require './facility/usage.php';

