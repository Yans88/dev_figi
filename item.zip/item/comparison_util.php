<?php

function comparison_count()
{
	return 0;
}

function comparison_get_list($orderby, $orderdir, $start = 0, $limit = 10)
{
	$result =  null;
	return $result;
	
}


